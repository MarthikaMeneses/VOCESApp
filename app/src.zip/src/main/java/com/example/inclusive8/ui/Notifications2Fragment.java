package com.example.inclusive8.ui;

import android.app.Activity;

public class Notifications2Fragment extends Activity {
}
